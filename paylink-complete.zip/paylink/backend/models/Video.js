const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String },
  videoUrl: { type: String, required: true },
  thumbnailUrl: { type: String },
  duration: { type: Number, default: 0 }, // in seconds

  // Creator
  creatorId: { type: String, required: true },
  creatorName: { type: String },

  // Campaign Details
  rewardPerView: { type: Number, default: 1 }, // GHS per view
  maxViews: { type: Number, default: 1000 },
  currentViews: { type: Number, default: 0 },
  budget: { type: Number, default: 0 }, // Total budget allocated

  // Status
  isActive: { type: Boolean, default: false },
  isApproved: { type: Boolean, default: false },
  isPaid: { type: Boolean, default: false },

  // Analytics
  viewers: [{ type: String }], // telegramIds who watched
  likes: { type: Number, default: 0 },
  completionRate: { type: Number, default: 0 },

  // Payment
  paystackReference: { type: String },
  paidAt: { type: Date },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

videoSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

module.exports = mongoose.model('Video', videoSchema);
