const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Video = require('../models/Video');
const Transaction = require('../models/Transaction');
const Withdrawal = require('../models/Withdrawal');
const { telegramAuth, adminOnly } = require('../middleware/auth');

// Dashboard stats
router.get('/stats', telegramAuth, adminOnly, async (req, res) => {
  try {
    const [totalUsers, paidUsers, totalVideos, pendingWithdrawals] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ isPaid: true }),
      Video.countDocuments(),
      Withdrawal.countDocuments({ status: 'pending' })
    ]);

    const revenue = await Transaction.aggregate([
      { $match: { type: { $in: ['registration', 'creator_fee'] }, status: 'completed' } },
      { $group: { _id: null, total: { $sum: '$amount' } } }
    ]);

    res.json({
      success: true,
      stats: {
        totalUsers,
        paidUsers,
        freeUsers: totalUsers - paidUsers,
        totalVideos,
        pendingWithdrawals,
        totalRevenue: revenue[0]?.total || 0
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all users
router.get('/users', telegramAuth, adminOnly, async (req, res) => {
  try {
    const { page = 1, limit = 20, search, isPaid } = req.query;
    const query = {};
    if (search) query.$or = [
      { firstName: new RegExp(search, 'i') },
      { username: new RegExp(search, 'i') },
      { telegramId: search }
    ];
    if (isPaid !== undefined) query.isPaid = isPaid === 'true';

    const users = await User.find(query)
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    const total = await User.countDocuments(query);
    res.json({ success: true, users, total, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Ban/unban user
router.patch('/users/:telegramId/ban', telegramAuth, adminOnly, async (req, res) => {
  try {
    const user = await User.findOne({ telegramId: req.params.telegramId });
    if (!user) return res.status(404).json({ error: 'User not found' });
    user.isBanned = !user.isBanned;
    await user.save();
    res.json({ success: true, message: `User ${user.isBanned ? 'banned' : 'unbanned'}`, isBanned: user.isBanned });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Manually verify payment
router.patch('/users/:telegramId/verify-payment', telegramAuth, adminOnly, async (req, res) => {
  try {
    const user = await User.findOneAndUpdate(
      { telegramId: req.params.telegramId },
      { isPaid: true, paidAt: new Date() },
      { new: true }
    );
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ success: true, message: 'Payment verified manually', user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get pending withdrawals
router.get('/withdrawals', telegramAuth, adminOnly, async (req, res) => {
  try {
    const { status = 'pending' } = req.query;
    const withdrawals = await Withdrawal.find({ status }).sort({ createdAt: -1 });
    res.json({ success: true, withdrawals });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Approve/reject withdrawal
router.patch('/withdrawals/:id', telegramAuth, adminOnly, async (req, res) => {
  try {
    const { status, adminNote } = req.body; // 'approved' or 'rejected'
    if (!['approved', 'rejected', 'paid'].includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }

    const withdrawal = await Withdrawal.findByIdAndUpdate(
      req.params.id,
      { status, adminNote, approvedBy: req.user.telegramId, approvedAt: new Date() },
      { new: true }
    );

    if (!withdrawal) return res.status(404).json({ error: 'Withdrawal not found' });

    // If rejected, refund balance
    if (status === 'rejected') {
      await User.findOneAndUpdate(
        { telegramId: withdrawal.userId },
        { $inc: { balance: withdrawal.amount } }
      );
    }

    res.json({ success: true, withdrawal, message: `Withdrawal ${status}` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all video campaigns
router.get('/campaigns', telegramAuth, adminOnly, async (req, res) => {
  try {
    const videos = await Video.find().sort({ createdAt: -1 });
    res.json({ success: true, videos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Approve/reject video campaign
router.patch('/campaigns/:videoId', telegramAuth, adminOnly, async (req, res) => {
  try {
    const { action } = req.body; // 'approve' or 'reject'
    const video = await Video.findById(req.params.videoId);
    if (!video) return res.status(404).json({ error: 'Video not found' });

    if (action === 'approve') {
      video.isApproved = true;
      video.isActive = true;
    } else if (action === 'reject') {
      video.isApproved = false;
      video.isActive = false;
    }

    await video.save();
    res.json({ success: true, video, message: `Campaign ${action}d` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
