const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { telegramAuth } = require('../middleware/auth');

// Register or login user
router.post('/register', async (req, res) => {
  try {
    const { telegramId, username, firstName, lastName, photoUrl, referralCode } = req.body;

    if (!telegramId || !firstName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    let user = await User.findOne({ telegramId: telegramId.toString() });

    if (user) {
      return res.json({ success: true, user, isNew: false });
    }

    // Generate unique referral code
    let refCode;
    let isUnique = false;
    while (!isUnique) {
      refCode = User.generateReferralCode(telegramId);
      const existing = await User.findOne({ referralCode: refCode });
      if (!existing) isUnique = true;
    }

    // Check if referred by someone
    let referrer = null;
    if (referralCode) {
      referrer = await User.findOne({ referralCode });
    }

    user = new User({
      telegramId: telegramId.toString(),
      username,
      firstName,
      lastName,
      photoUrl,
      referralCode: refCode,
      referredBy: referrer ? referrer.telegramId : null
    });

    await user.save();

    res.json({ success: true, user, isNew: true, referrer: referrer ? referrer.firstName : null });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get current user profile
router.get('/me', telegramAuth, async (req, res) => {
  try {
    const user = await User.findOne({ telegramId: req.user.telegramId });
    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get referral info
router.get('/referrals', telegramAuth, async (req, res) => {
  try {
    const referrals = await User.find(
      { referredBy: req.user.telegramId },
      'firstName lastName username isPaid createdAt'
    );
    res.json({
      success: true,
      referralCode: req.user.referralCode,
      referralLink: `https://t.me/${process.env.TELEGRAM_BOT_USERNAME}?start=${req.user.referralCode}`,
      referrals,
      earnings: req.user.referralEarnings,
      count: referrals.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
