const express = require('express');
const router = express.Router();
const Video = require('../models/Video');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const { telegramAuth, paidOnly } = require('../middleware/auth');

// Get available video tasks
router.get('/', telegramAuth, paidOnly, async (req, res) => {
  try {
    const user = req.user;
    const videos = await Video.find({
      isActive: true,
      isApproved: true,
      isPaid: true,
      $expr: { $lt: ['$currentViews', '$maxViews'] },
      viewers: { $nin: [user.telegramId] } // Not already watched
    }).select('-viewers').limit(20);

    res.json({ success: true, videos, watchedCount: user.watchedVideos.length });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Complete a video task (earn reward)
router.post('/:videoId/complete', telegramAuth, paidOnly, async (req, res) => {
  try {
    const { videoId } = req.params;
    const user = req.user;

    const video = await Video.findById(videoId);
    if (!video) return res.status(404).json({ error: 'Video not found' });

    if (!video.isActive || !video.isApproved) {
      return res.status(400).json({ error: 'This task is not available' });
    }

    if (video.viewers.includes(user.telegramId)) {
      return res.status(400).json({ error: 'You already completed this task' });
    }

    if (video.currentViews >= video.maxViews) {
      return res.status(400).json({ error: 'This task has reached its view limit' });
    }

    // Award user
    const reward = video.rewardPerView;
    await User.findOneAndUpdate(
      { telegramId: user.telegramId },
      {
        $inc: { balance: reward, taskEarnings: reward, totalEarned: reward },
        $push: { watchedVideos: video._id }
      }
    );

    // Update video stats
    await Video.findByIdAndUpdate(videoId, {
      $inc: { currentViews: 1 },
      $push: { viewers: user.telegramId }
    });

    // Record transaction
    await Transaction.create({
      userId: user.telegramId,
      type: 'video_earning',
      amount: reward,
      status: 'completed',
      description: `Earned from watching: ${video.title}`,
      metadata: { videoId }
    });

    // Deactivate video if max views reached
    if (video.currentViews + 1 >= video.maxViews) {
      await Video.findByIdAndUpdate(videoId, { isActive: false });
    }

    res.json({ success: true, reward, message: `You earned GHS ${reward}!` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get user's task history
router.get('/history', telegramAuth, paidOnly, async (req, res) => {
  try {
    const transactions = await Transaction.find({
      userId: req.user.telegramId,
      type: 'video_earning'
    }).sort({ createdAt: -1 }).limit(50);

    res.json({ success: true, transactions, totalEarned: req.user.taskEarnings });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
