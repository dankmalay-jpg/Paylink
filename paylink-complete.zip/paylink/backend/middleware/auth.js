const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Verify Telegram WebApp initData
const verifyTelegramData = (initData) => {
  const urlParams = new URLSearchParams(initData);
  const hash = urlParams.get('hash');
  urlParams.delete('hash');

  const dataCheckArr = [];
  urlParams.sort();
  urlParams.forEach((val, key) => dataCheckArr.push(`${key}=${val}`));
  const dataCheckString = dataCheckArr.join('\n');

  const secretKey = crypto.createHmac('sha256', 'WebAppData')
    .update(process.env.TELEGRAM_BOT_TOKEN)
    .digest();

  const computedHash = crypto.createHmac('sha256', secretKey)
    .update(dataCheckString)
    .digest('hex');

  return computedHash === hash;
};

// Middleware: Authenticate via Telegram initData
const telegramAuth = async (req, res, next) => {
  try {
    const initData = req.headers['x-telegram-init-data'];
    if (!initData) return res.status(401).json({ error: 'No auth data provided' });

    // In dev mode, skip verification
    if (process.env.NODE_ENV !== 'development') {
      if (!verifyTelegramData(initData)) {
        return res.status(401).json({ error: 'Invalid Telegram data' });
      }
    }

    const urlParams = new URLSearchParams(initData);
    const userParam = urlParams.get('user');
    if (!userParam) return res.status(401).json({ error: 'No user data' });

    const telegramUser = JSON.parse(userParam);
    let user = await User.findOne({ telegramId: telegramUser.id.toString() });

    if (!user) {
      return res.status(404).json({ error: 'User not found. Please register first.' });
    }

    req.user = user;
    req.telegramUser = telegramUser;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Authentication failed', details: err.message });
  }
};

// Middleware: Admin only
const adminOnly = (req, res, next) => {
  const adminIds = (process.env.ADMIN_IDS || '').split(',').map(id => id.trim());
  if (!adminIds.includes(req.user.telegramId) && !req.user.isAdmin) {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
};

// Middleware: Paid users only
const paidOnly = (req, res, next) => {
  if (!req.user.isPaid) {
    return res.status(403).json({ error: 'Payment required to access this feature', requiresPayment: true });
  }
  next();
};

module.exports = { telegramAuth, adminOnly, paidOnly, verifyTelegramData };
