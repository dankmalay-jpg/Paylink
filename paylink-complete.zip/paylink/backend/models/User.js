const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  telegramId: { type: String, required: true, unique: true },
  username: { type: String },
  firstName: { type: String, required: true },
  lastName: { type: String },
  photoUrl: { type: String },

  // Account Status
  isPaid: { type: Boolean, default: false },
  isCreator: { type: Boolean, default: false },
  isAdmin: { type: Boolean, default: false },
  isBanned: { type: Boolean, default: false },

  // Balance
  balance: { type: Number, default: 0 },
  totalEarned: { type: Number, default: 0 },
  totalWithdrawn: { type: Number, default: 0 },

  // Referral System
  referralCode: { type: String, unique: true },
  referredBy: { type: String, default: null },
  referrals: [{ type: String }],
  referralEarnings: { type: Number, default: 0 },

  // Video Tasks
  watchedVideos: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Video' }],
  taskEarnings: { type: Number, default: 0 },

  // Payment
  paystackReference: { type: String },
  paidAt: { type: Date },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

userSchema.pre('save', function(next) {
  this.updatedAt = new Date();
  next();
});

// Generate referral code
userSchema.statics.generateReferralCode = function(telegramId) {
  return 'PL' + telegramId.toString().slice(-4) + Math.random().toString(36).substring(2, 6).toUpperCase();
};

module.exports = mongoose.model('User', userSchema);
