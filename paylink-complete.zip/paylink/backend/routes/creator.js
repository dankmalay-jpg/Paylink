const express = require('express');
const router = express.Router();
const Video = require('../models/Video');
const { telegramAuth, paidOnly } = require('../middleware/auth');

// Middleware to check creator status
const creatorOnly = (req, res, next) => {
  if (!req.user.isCreator) {
    return res.status(403).json({ error: 'Creator account required', requiresCreator: true });
  }
  next();
};

// Get creator's videos
router.get('/videos', telegramAuth, creatorOnly, async (req, res) => {
  try {
    const videos = await Video.find({ creatorId: req.user.telegramId }).sort({ createdAt: -1 });
    const stats = {
      totalVideos: videos.length,
      totalViews: videos.reduce((sum, v) => sum + v.currentViews, 0),
      activeVideos: videos.filter(v => v.isActive).length,
      pendingApproval: videos.filter(v => !v.isApproved).length
    };
    res.json({ success: true, videos, stats });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Upload/create a new video campaign
router.post('/videos', telegramAuth, creatorOnly, async (req, res) => {
  try {
    const { title, description, videoUrl, thumbnailUrl, rewardPerView, maxViews } = req.body;

    if (!title || !videoUrl) {
      return res.status(400).json({ error: 'Title and video URL are required' });
    }

    const reward = parseFloat(rewardPerView) || 1;
    const views = parseInt(maxViews) || 100;
    const budget = reward * views;

    const video = await Video.create({
      title,
      description,
      videoUrl,
      thumbnailUrl,
      rewardPerView: reward,
      maxViews: views,
      budget,
      creatorId: req.user.telegramId,
      creatorName: req.user.firstName,
      isActive: false,
      isApproved: false,
      isPaid: false
    });

    res.json({
      success: true,
      video,
      message: 'Video campaign created! Awaiting admin approval.',
      estimatedCost: budget
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get analytics for a specific video
router.get('/videos/:videoId/analytics', telegramAuth, creatorOnly, async (req, res) => {
  try {
    const video = await Video.findOne({
      _id: req.params.videoId,
      creatorId: req.user.telegramId
    });
    if (!video) return res.status(404).json({ error: 'Video not found' });

    const completionRate = video.maxViews > 0
      ? ((video.currentViews / video.maxViews) * 100).toFixed(1)
      : 0;

    res.json({
      success: true,
      analytics: {
        title: video.title,
        totalViews: video.currentViews,
        maxViews: video.maxViews,
        completionRate: `${completionRate}%`,
        totalSpent: (video.currentViews * video.rewardPerView).toFixed(2),
        budget: video.budget,
        remainingBudget: (video.budget - (video.currentViews * video.rewardPerView)).toFixed(2),
        status: video.isActive ? 'Active' : video.isApproved ? 'Inactive' : 'Pending Approval'
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
