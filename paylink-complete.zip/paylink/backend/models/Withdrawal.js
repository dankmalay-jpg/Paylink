const mongoose = require('mongoose');

const withdrawalSchema = new mongoose.Schema({
  userId: { type: String, required: true },
  amount: { type: Number, required: true },
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'paid'],
    default: 'pending'
  },
  paymentMethod: {
    type: String,
    enum: ['momo', 'bank'],
    required: true
  },
  accountDetails: {
    accountNumber: { type: String, required: true },
    accountName: { type: String, required: true },
    network: { type: String } // for MoMo: MTN, Vodafone, AirtelTigo
  },
  adminNote: { type: String },
  approvedBy: { type: String },
  approvedAt: { type: Date },
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Withdrawal', withdrawalSchema);
