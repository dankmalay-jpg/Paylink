# 💰 PayLink - Telegram Mini App

Watch videos. Earn money. Refer friends. Built for MT5... upgraded for the world.

---

## 🗂️ Project Structure

```
paylink/
├── frontend/
│   └── index.html          # Complete Telegram Mini App UI
├── backend/
│   ├── server.js           # Main Express server
│   ├── bot.js              # Telegram bot commands
│   ├── models/
│   │   ├── User.js
│   │   ├── Video.js
│   │   ├── Transaction.js
│   │   └── Withdrawal.js
│   ├── routes/
│   │   ├── auth.js         # Register, login, referrals
│   │   ├── payments.js     # Paystack, withdrawals
│   │   ├── tasks.js        # Video tasks
│   │   ├── creator.js      # Creator dashboard
│   │   └── admin.js        # Admin panel
│   └── middleware/
│       └── auth.js         # Telegram auth verification
├── package.json
├── .env.example
└── README.md
```

---

## 🚀 Getting Started (Zero Cost Deployment)

### Step 1: Prerequisites (All Free)
- Node.js 18+ → https://nodejs.org
- MongoDB Atlas (Free tier) → https://mongodb.com/atlas
- Render.com (Free hosting) → https://render.com
- Paystack account → https://paystack.com

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Set Up Environment
```bash
cp .env.example .env
```
Edit `.env` with your values:
```
TELEGRAM_BOT_TOKEN=8018262306:AAFBxk-HdBBcKzNvyggTNI1IAcKh62eVv5U
TELEGRAM_BOT_USERNAME=paylink_bot
WEBAPP_URL=https://your-app.onrender.com
MONGODB_URI=mongodb+srv://...your atlas URI...
JWT_SECRET=any-random-long-string-here
PAYSTACK_SECRET_KEY=sk_live_...
PAYSTACK_PUBLIC_KEY=pk_live_...
ADMIN_IDS=your_telegram_id_here
PORT=3000
NODE_ENV=production
```

### Step 4: Run Locally (Dev)
```bash
NODE_ENV=development npm run dev
```
Visit: http://localhost:3000

---

## ☁️ FREE Deployment on Render.com

1. Push your code to GitHub (free)
2. Go to https://render.com → New → Web Service
3. Connect your GitHub repo
4. Settings:
   - **Build Command**: `npm install`
   - **Start Command**: `node backend/server.js`
   - **Environment**: Add all your `.env` variables
5. Deploy → Get your URL (e.g. `https://paylink.onrender.com`)
6. Set `WEBAPP_URL` to that URL

---

## 🤖 Connect Bot to Mini App

1. Message @BotFather on Telegram
2. Send: `/newapp`
3. Select your bot: `@paylink_bot`
4. Set Web App URL to your Render URL
5. Done! Send `/start` to your bot to test

### ⚠️ IMPORTANT: Regenerate Bot Token
Your token was shared publicly. Do this NOW:
1. Go to @BotFather
2. Select your bot
3. Click "API Token" → "Revoke current token"
4. Update your `.env` with the new token

---

## 💳 Paystack Setup

1. Sign up at paystack.com (free)
2. Go to Settings → API Keys
3. Copy your Secret Key and Public Key
4. Add to `.env`
5. For GHS payments, make sure your account is Ghana-based

---

## 📱 Features

| Feature | Description |
|---------|-------------|
| 🔐 Auth | Telegram login (no password needed) |
| 💰 Payment | Paystack - 100 GHS registration |
| 🎬 Tasks | Watch videos, earn per view |
| 👥 Referrals | GHS 3 per paid referral |
| 🎥 Creator | Upload campaigns (500 GHS) |
| 🛡️ Admin | Manage users, withdrawals, campaigns |
| 💸 Withdraw | MoMo or Bank Transfer |

---

## 💡 Revenue Model

- **Registration**: 100 GHS × users = revenue
- **Creator fees**: 500 GHS per creator
- **Margin**: Platform keeps difference between creator budget and user earnings

---

## 🛡️ Admin Access

Set your Telegram ID in `ADMIN_IDS` env variable.
Find your ID by messaging @userinfobot on Telegram.

---

## 📞 Support

Built with ❤️ using Node.js, MongoDB, Paystack & Telegram Mini Apps SDK.
