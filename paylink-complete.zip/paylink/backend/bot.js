require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const User = require('./models/User');

const bot = new TelegramBot(process.env.TELEGRAM_BOT_TOKEN, { polling: false });
const WEBAPP_URL = process.env.WEBAPP_URL;
const BOT_USERNAME = process.env.TELEGRAM_BOT_USERNAME || 'paylink_bot';

// Set bot commands menu
const setBotCommands = async () => {
  await bot.setMyCommands([
    { command: 'start', description: '🚀 Start PayLink & Register' },
    { command: 'dashboard', description: '📊 Open Dashboard' },
    { command: 'balance', description: '💰 Check your balance' },
    { command: 'tasks', description: '🎬 Browse video tasks' },
    { command: 'referral', description: '👥 Get your referral link' },
    { command: 'withdraw', description: '💸 Request withdrawal' },
    { command: 'creator', description: '🎥 Creator dashboard' },
    { command: 'help', description: '❓ How PayLink works' },
    { command: 'support', description: '💬 Contact support' }
  ]);
};

// Helper: Send message with Mini App button
const sendMiniApp = (chatId, text, path = '') => {
  return bot.sendMessage(chatId, text, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[
        {
          text: '🚀 Open PayLink App',
          web_app: { url: `${WEBAPP_URL}${path}` }
        }
      ]]
    }
  });
};

// /start command
bot.onText(/\/start(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const telegramId = msg.from.id.toString();
  const referralCode = match[1]?.trim();

  let user = await User.findOne({ telegramId });

  const welcomeNew = `
🎉 <b>Welcome to PayLink!</b>

Turn your time into money by watching videos & referring friends!

💰 <b>How it works:</b>
1. Pay <b>100 GHS</b> to activate your account
2. Watch videos & earn real money
3. Refer friends → earn <b>3 GHS</b> per referral
4. Withdraw anytime via MoMo or Bank

${referralCode ? `✅ You were referred! Your referrer will earn when you pay.` : ''}

👇 Tap below to get started!
  `;

  const welcomeBack = `
👋 <b>Welcome back, ${user?.firstName || 'friend'}!</b>

💰 Balance: <b>GHS ${user?.balance?.toFixed(2) || '0.00'}</b>
📊 Status: ${user?.isPaid ? '✅ Active' : '⚠️ Payment Required'}

Tap below to open your dashboard!
  `;

  sendMiniApp(chatId, user ? welcomeBack : welcomeNew, user ? '/dashboard' : `/?ref=${referralCode}`);
});

// /dashboard command
bot.onText(/\/dashboard/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user) {
    return bot.sendMessage(msg.chat.id, '❌ Please register first! Use /start');
  }
  sendMiniApp(msg.chat.id, '📊 Opening your dashboard...', '/dashboard');
});

// /balance command
bot.onText(/\/balance/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user) return bot.sendMessage(msg.chat.id, '❌ Not registered. Use /start');

  bot.sendMessage(msg.chat.id, `
💰 <b>Your PayLink Balance</b>

💵 Available: <b>GHS ${user.balance.toFixed(2)}</b>
📈 Total Earned: <b>GHS ${user.totalEarned.toFixed(2)}</b>
📤 Total Withdrawn: <b>GHS ${user.totalWithdrawn.toFixed(2)}</b>
👥 Referral Earnings: <b>GHS ${user.referralEarnings.toFixed(2)}</b>
  `, {
    parse_mode: 'HTML',
    reply_markup: {
      inline_keyboard: [[
        { text: '💸 Withdraw', web_app: { url: `${WEBAPP_URL}/withdraw` } },
        { text: '🎬 Earn More', web_app: { url: `${WEBAPP_URL}/tasks` } }
      ]]
    }
  });
});

// /referral command
bot.onText(/\/referral/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user) return bot.sendMessage(msg.chat.id, '❌ Not registered. Use /start');

  const link = `https://t.me/${BOT_USERNAME}?start=${user.referralCode}`;
  bot.sendMessage(msg.chat.id, `
👥 <b>Your Referral Program</b>

🔗 Your link: <code>${link}</code>

💰 Earn <b>GHS 3</b> for every friend who registers & pays!
📊 Total referrals: <b>${user.referrals.length}</b>
💵 Referral earnings: <b>GHS ${user.referralEarnings.toFixed(2)}</b>

Share your link and start earning! 🚀
  `, { parse_mode: 'HTML' });
});

// /tasks command
bot.onText(/\/tasks/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user?.isPaid) {
    return bot.sendMessage(msg.chat.id, '⚠️ You need to pay 100 GHS to access tasks. Use /start');
  }
  sendMiniApp(msg.chat.id, '🎬 Opening video tasks...', '/tasks');
});

// /withdraw command
bot.onText(/\/withdraw/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user?.isPaid) return bot.sendMessage(msg.chat.id, '⚠️ Payment required. Use /start');
  sendMiniApp(msg.chat.id, '💸 Opening withdrawal page...', '/withdraw');
});

// /creator command
bot.onText(/\/creator/, async (msg) => {
  const user = await User.findOne({ telegramId: msg.from.id.toString() });
  if (!user?.isCreator) {
    return bot.sendMessage(msg.chat.id, `
🎥 <b>Become a PayLink Creator!</b>

Upload videos and get them watched by thousands of users!

💰 Cost: <b>GHS 500 one-time</b>
📊 Track views & engagement
🎯 Target engaged audience

Tap below to upgrade!
    `, {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [[
          { text: '🎥 Upgrade to Creator', web_app: { url: `${WEBAPP_URL}/creator/upgrade` } }
        ]]
      }
    });
    return;
  }
  sendMiniApp(msg.chat.id, '🎥 Opening creator dashboard...', '/creator');
});

// /help command
bot.onText(/\/help/, (msg) => {
  bot.sendMessage(msg.chat.id, `
❓ <b>How PayLink Works</b>

<b>👤 For Users:</b>
• Pay 100 GHS to activate your account
• Watch videos and earn money per view
• Refer friends → earn 3 GHS each time they pay
• Withdraw via MTN MoMo or Bank Transfer

<b>🎥 For Creators:</b>
• Pay 500 GHS to become a creator
• Upload your videos as campaigns
• Set your budget and reward per view
• Track views and engagement in real-time

<b>💸 Withdrawals:</b>
• Minimum: 10 GHS
• Processed within 24 hours
• Via MoMo or Bank Transfer

<b>📞 Need help?</b> Use /support
  `, { parse_mode: 'HTML' });
});

// /support command
bot.onText(/\/support/, (msg) => {
  bot.sendMessage(msg.chat.id, `
💬 <b>PayLink Support</b>

Need help? Our team is ready!

📧 Describe your issue and we'll get back to you.
⏰ Response time: within 2 hours

Please send your message below and include your Telegram ID: <code>${msg.from.id}</code>
  `, { parse_mode: 'HTML' });
});

// Handle unknown commands
bot.on('message', (msg) => {
  if (msg.text && msg.text.startsWith('/') && !msg.text.match(/^\/(start|dashboard|balance|tasks|referral|withdraw|creator|help|support)/)) {
    bot.sendMessage(msg.chat.id, '❓ Unknown command. Use /help to see all available commands.');
  }
});

module.exports = { bot, setBotCommands };
