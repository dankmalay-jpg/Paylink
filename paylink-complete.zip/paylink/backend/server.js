require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const { bot, setBotCommands } = require('./bot');

const app = express();
const PORT = process.env.PORT || 3000;

// =============================================
// Middleware
// =============================================
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 100 });
app.use('/api/', limiter);

// =============================================
// Database Connection
// =============================================
mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/paylink')
  .then(() => {
    console.log('✅ MongoDB connected');
    setBotCommands().then(() => console.log('✅ Bot commands registered'));
  })
  .catch(err => console.error('❌ MongoDB error:', err));

// =============================================
// API Routes
// =============================================
app.use('/api/auth', require('./routes/auth'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/creator', require('./routes/creator'));
app.use('/api/admin', require('./routes/admin'));

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0', app: 'PayLink' });
});

// =============================================
// Telegram Webhook (for production)
// =============================================
if (process.env.NODE_ENV === 'production' && process.env.WEBAPP_URL) {
  const webhookPath = `/webhook/${process.env.TELEGRAM_BOT_TOKEN}`;
  app.post(webhookPath, (req, res) => {
    bot.processUpdate(req.body);
    res.sendStatus(200);
  });

  // Set webhook
  bot.setWebHook(`${process.env.WEBAPP_URL}${webhookPath}`)
    .then(() => console.log('✅ Telegram webhook set'))
    .catch(err => console.error('❌ Webhook error:', err));
} else {
  // Use polling in development
  bot.startPolling();
  console.log('✅ Bot polling started (dev mode)');
}

// =============================================
// Serve Frontend (SPA fallback)
// =============================================
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// =============================================
// Start Server
// =============================================
app.listen(PORT, () => {
  console.log(`
  ██████╗  █████╗ ██╗   ██╗██╗     ██╗███╗   ██╗██╗  ██╗
  ██╔══██╗██╔══██╗╚██╗ ██╔╝██║     ██║████╗  ██║██║ ██╔╝
  ██████╔╝███████║ ╚████╔╝ ██║     ██║██╔██╗ ██║█████╔╝ 
  ██╔═══╝ ██╔══██║  ╚██╔╝  ██║     ██║██║╚██╗██║██╔═██╗ 
  ██║     ██║  ██║   ██║   ███████╗██║██║ ╚████║██║  ██╗
  ╚═╝     ╚═╝  ╚═╝   ╚═╝   ╚══════╝╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝
  
  🚀 PayLink Server running on port ${PORT}
  🌐 URL: ${process.env.WEBAPP_URL || `http://localhost:${PORT}`}
  `);
});

module.exports = app;
