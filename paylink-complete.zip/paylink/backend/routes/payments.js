const express = require('express');
const router = express.Router();
const axios = require('axios');
const crypto = require('crypto');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const Withdrawal = require('../models/Withdrawal');
const { telegramAuth, paidOnly } = require('../middleware/auth');

const PAYSTACK_SECRET = process.env.PAYSTACK_SECRET_KEY;
const REGISTRATION_FEE = parseInt(process.env.REGISTRATION_FEE || 100);
const CREATOR_FEE = parseInt(process.env.CREATOR_FEE || 500);
const REFERRAL_BONUS = parseInt(process.env.REFERRAL_BONUS || 3);

// Initialize registration payment (100 GHS)
router.post('/initialize', telegramAuth, async (req, res) => {
  try {
    if (req.user.isPaid) {
      return res.json({ success: true, message: 'Already paid', alreadyPaid: true });
    }

    const amountInPesewas = REGISTRATION_FEE * 100; // Paystack uses smallest currency unit
    const email = `${req.user.telegramId}@paylink.app`;
    const reference = `REG_${req.user.telegramId}_${Date.now()}`;

    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      {
        email,
        amount: amountInPesewas,
        currency: 'GHS',
        reference,
        callback_url: `${process.env.WEBAPP_URL}/payment/callback`,
        metadata: {
          telegramId: req.user.telegramId,
          type: 'registration',
          custom_fields: [
            { display_name: 'Telegram ID', variable_name: 'telegram_id', value: req.user.telegramId },
            { display_name: 'Name', variable_name: 'name', value: req.user.firstName }
          ]
        }
      },
      { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}`, 'Content-Type': 'application/json' } }
    );

    // Save pending transaction
    await Transaction.create({
      userId: req.user.telegramId,
      type: 'registration',
      amount: REGISTRATION_FEE,
      status: 'pending',
      reference,
      description: 'PayLink Registration Fee'
    });

    res.json({
      success: true,
      authorization_url: response.data.data.authorization_url,
      reference,
      amount: REGISTRATION_FEE
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Initialize creator payment (500 GHS)
router.post('/creator/initialize', telegramAuth, paidOnly, async (req, res) => {
  try {
    if (req.user.isCreator) {
      return res.json({ success: true, message: 'Already a creator', alreadyCreator: true });
    }

    const amountInPesewas = CREATOR_FEE * 100;
    const email = `creator_${req.user.telegramId}@paylink.app`;
    const reference = `CREATOR_${req.user.telegramId}_${Date.now()}`;

    const response = await axios.post(
      'https://api.paystack.co/transaction/initialize',
      {
        email,
        amount: amountInPesewas,
        currency: 'GHS',
        reference,
        callback_url: `${process.env.WEBAPP_URL}/payment/callback`,
        metadata: { telegramId: req.user.telegramId, type: 'creator_fee' }
      },
      { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}`, 'Content-Type': 'application/json' } }
    );

    await Transaction.create({
      userId: req.user.telegramId,
      type: 'creator_fee',
      amount: CREATOR_FEE,
      status: 'pending',
      reference,
      description: 'PayLink Creator Upgrade Fee'
    });

    res.json({
      success: true,
      authorization_url: response.data.data.authorization_url,
      reference,
      amount: CREATOR_FEE
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Verify payment (called after Paystack redirect)
router.get('/verify/:reference', async (req, res) => {
  try {
    const { reference } = req.params;

    const response = await axios.get(
      `https://api.paystack.co/transaction/verify/${reference}`,
      { headers: { Authorization: `Bearer ${PAYSTACK_SECRET}` } }
    );

    const data = response.data.data;
    if (data.status !== 'success') {
      return res.json({ success: false, message: 'Payment not successful' });
    }

    const telegramId = data.metadata?.telegramId;
    const type = data.metadata?.type;
    const user = await User.findOne({ telegramId });
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (type === 'registration' && !user.isPaid) {
      user.isPaid = true;
      user.paystackReference = reference;
      user.paidAt = new Date();
      await user.save();

      // Award referral bonus to referrer
      if (user.referredBy) {
        const referrer = await User.findOne({ telegramId: user.referredBy });
        if (referrer && referrer.isPaid) {
          referrer.balance += REFERRAL_BONUS;
          referrer.referralEarnings += REFERRAL_BONUS;
          referrer.totalEarned += REFERRAL_BONUS;
          if (!referrer.referrals.includes(user.telegramId)) {
            referrer.referrals.push(user.telegramId);
          }
          await referrer.save();

          await Transaction.create({
            userId: referrer.telegramId,
            type: 'referral_bonus',
            amount: REFERRAL_BONUS,
            status: 'completed',
            description: `Referral bonus from ${user.firstName}`
          });
        }
      }
    } else if (type === 'creator_fee' && !user.isCreator) {
      user.isCreator = true;
      await user.save();
    }

    // Update transaction
    await Transaction.findOneAndUpdate(
      { reference },
      { status: 'completed', paystackReference: data.reference }
    );

    res.json({ success: true, type, user });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Paystack Webhook
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const hash = crypto.createHmac('sha512', PAYSTACK_SECRET)
    .update(req.body)
    .digest('hex');

  if (hash !== req.headers['x-paystack-signature']) {
    return res.status(401).send('Invalid signature');
  }

  const event = JSON.parse(req.body);

  if (event.event === 'charge.success') {
    const data = event.data;
    const reference = data.reference;
    await axios.get(`${process.env.WEBAPP_URL}/api/payments/verify/${reference}`).catch(() => {});
  }

  res.sendStatus(200);
});

// Request Withdrawal
router.post('/withdraw', telegramAuth, paidOnly, async (req, res) => {
  try {
    const { amount, paymentMethod, accountNumber, accountName, network } = req.body;
    const minWithdrawal = 10;

    if (amount < minWithdrawal) {
      return res.status(400).json({ error: `Minimum withdrawal is GHS ${minWithdrawal}` });
    }
    if (req.user.balance < amount) {
      return res.status(400).json({ error: 'Insufficient balance' });
    }

    // Deduct balance and create withdrawal request
    await User.findOneAndUpdate(
      { telegramId: req.user.telegramId },
      { $inc: { balance: -amount } }
    );

    const withdrawal = await Withdrawal.create({
      userId: req.user.telegramId,
      amount,
      paymentMethod,
      accountDetails: { accountNumber, accountName, network },
      status: 'pending'
    });

    res.json({ success: true, withdrawal, message: 'Withdrawal request submitted. Admin will process within 24hrs.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
